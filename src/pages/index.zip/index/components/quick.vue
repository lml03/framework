<template>
    <div>
        <p>这里是quick页面</p>


    </div>
</template>
<script>

    export default {
        mixins: [  ],
        components: { },
        data () {
            return {
                searchText:'',
                tableData3: [],
                aa:"AA",
                bb:"BB"
            }
        },
        computed:{
 
        },
        activated () {
 
        },
        methods: {


        }
    }
</script>

<style lang="scss" >

 p{ color: #999;}



</style>
