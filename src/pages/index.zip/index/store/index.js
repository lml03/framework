import Vue from 'vue'
import Vuex from 'vuex'
//import account from './modules/account'
//import companyList from './modules/companyList'


Vue.use(Vuex)
export default new Vuex.Store({
    actions: {},
    mutations: {},
    getters: {},
    modules: {
        //account,
       // companyList

    }
})
