export default {
    mounted() {
        this.$nextTick(() => {


        });

    },
    methods: {
        init() {
			
            //do nothing
        },
        saveRouting() {
            //do nothing
        },
        controlRouting() {
            //do nothing
        }

    }
};
