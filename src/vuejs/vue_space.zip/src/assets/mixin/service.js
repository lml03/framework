﻿var commonAjaxSetting = {
    'get': {
        dataType: "json",
        cache: false
    },
    'post': {
        dataType: "json",
        headers: {
            "Content-Type": "application/json"
        },
        data: {},
        cache: false
    },  
    'put': {
        dataType: "json",
        headers: {
            "Content-Type": "application/json"
        },
        data: {},
        cache: false
    },
    'delete': {
        dataType: "json",
        cache: false
    }
};

var ajaxCall = function(setting, type) {
    if (type === undefined) {
        type = 'get';
    }

    var sendData = commonAjaxSetting[type];
    sendData.type = type;
    if (sendData.headers && sendData.headers['Content-Type'] == "application/json") {
        setting.data = JSON.stringify(setting.data);
    }
    sendData = $.extend({}, sendData, setting);
    return $.ajax(sendData);
};

const baseUrl = ""
const baseNode = "/api/node/"



const info = {
    defaultErrorMsg: '网络异常，请稍后再试',
    insertUsbkey: '请插入USB Key',
    loginExpire:'登录信息已过期，请重新登录',
    error101Msg: '你的服务开小差了，请稍后再试'
};


export default {
    data() {
        return {
            aa:"AA",
            bb:"BB"
        }
    },
    methods: {
        successCheckCode(ret) {
            if (ret.code === 100) {
                this.$store.commit('updateAccount', { isLogin: false });
                this.$message.error(info.loginExpire);
                this.$router.replace('/login');
                return false;
            } else if (ret.code !== 0) {
                this.$message.error(ret.msg && Object.prototype.toString.call(ret.msg) != "[object Object]" ? ret.msg : info.defaultErrorMsg);
                return false;
            }
            return true;
        },
        successCheckCodeText(ret) {
            try {
                ret = JSON.parse(ret);
            } catch (error) {
                Indicator.close();
                alert("网络异常，请稍后再试");
                //              this.$message({
                //                  showClose: true,
                //                  message: '网络异常，请稍后再试',
                //                  type: 'error'
                //              });
                return false;
            }
            return ret;
        },        
        autoAjaxCall(setting, type) {
            var xhr = ajaxCall(setting, type);
            xhr.fail(() => {
                alert(info.defaultErrorMsg+"--提示");
            });
            return xhr;
        },
        //get 时拼接参数的方法
        parseParams(obj) {
            let params = '?';
            for (let param in obj) {
                if (obj[param]) {
                    params += param + '=' + encodeURIComponent(obj[param]) + '&';
                }
            }
            return params.slice(0, params.length - 1)
        },
        //please use "get set del add" as prefix


        // 通过token获取用户信息
        getUserInfo(data) {
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+'api/system/getUserInfo' + param});
        },        
        // 通过cookies中的token获取用户信息
        getUserInfoCookies(data) {
            return this.autoAjaxCall({ url: baseUrl+'api/system/getUserInfoByCookies'});
        },        
        //登录接口
        postSystemLogin (data) {
            return this.autoAjaxCall({ url: baseUrl+'api/system/login', data: data }, 'post');
        },  
        // 登出接口 
        getLogout(data) {
            return this.autoAjaxCall({ url: baseUrl+'api/system/logout'});
        },                        
        unitNameFuzzyQuery (data){    //单位名称模糊查询 
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+ 'api/unit/nameFuzzyQuery' + param});
        },
        unitExactMatchQuery (data){     //通过公司名称，统一社会信用代码，营业执照，印章编码进行精确匹配查询             
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+ 'api/unit/exactMatchQuery' + param});
        },
        codeDictionaryQuery (data){     //根据type查询字典数据         
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+ 'api/codeDictionary/queryByType' + param});
        },
        getCodeArea (area_code){          //根据行政区域代码获取下级行政区域信息            
            return this.autoAjaxCall({ url: baseUrl+ 'api/codeArea/queryCodeArea?area_code=' + area_code});
        },
        getQueryCodeArea (data){          //根据行政区域代码获取下级行政区域信息       
            let param = this.parseParams(data)     
            return this.autoAjaxCall({ url: baseUrl+ 'api/codeArea/queryCodeArea' + param});
        },        
        getAdminUserList (data){     //查询管理员接口        
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+ 'api/adminUser/list' + param});
        },
        postSaveOrUpdate (data){     //保存管理员接口 
            return this.autoAjaxCall({ url: baseUrl+ 'api/adminUser/saveOrUpdate', data: data }, 'post'); 
        },
        getCheckUsername (data){     //检查用户名是否存在                   
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+ 'api/adminUser/checkUsername' + param});
        },
        getUserDelete (data){     // 删除用户
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+ 'api/adminUser/delete' + param});
        },      
        getAdminUserLsit (data){     // 查询管理员接口                   
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+ 'api/adminUser/list' + param});
        },                
        getSelectUserPrewarningResult (data){     //查询用户预警结果列表               
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+ 'api/userPreWarningResult/selectUserPrewarningResult' + param});
        },
        postComfirmPrewarningResult (data){     //用户确认预警结果
            return this.autoAjaxCall({ url: baseUrl+ 'api/userPreWarningResult/comfirmPrewarningResult', data: data }, 'post'); 
        },
        getSelectRuleDetail (data){     // 查询预警规则               
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+ 'api/preWarning/selectRuleDetail' + param});
        },
        getCheckRule (data){     // 检验预警规则是否存在          
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+ 'api/preWarning/checkRule' + param});
        },
        getDeleteRule (data){     //  删除预警规则        
            let param = this.parseParams(data)
            return this.autoAjaxCall({ url: baseUrl+ 'api/preWarning/deleteRule' + param});
        },
        postAddRule (data){     //POST / 新增预警规则
            return this.autoAjaxCall({ url: baseUrl+ 'api/preWarning/addRule', data: data }, 'post'); 
        },
        postUpdateRule (data){     //修改预警规则
            return this.autoAjaxCall({ url: baseUrl+ 'api/preWarning/updateRule', data: data }, 'post'); 
        },

        // unitNameFuzzyQuery (data){    //这是个样例
        //     let param = this.parseParams(data)
        //     return this.autoAjaxCall({ url: baseUrl+ 'api/unit/nameFuzzyQuery' + param, headers:{'Content-Type':'text/html'}  });
        // }        

        // //base64图片上传；
        // uploadByBase64(data) {
        //     return this.autoAjaxCall({ url: '/api/filesys/image/uploadByBase64', data: data }, 'post');
        // },    
        // getGenerateCertifyCode(data){
        //     let param = this.parseParams(data)
        //     return this.autoAjaxCall({ url: baseNode+ 'generate_certify_code' + param});
        // },
        // //获取短信
        // sendMsgAli(data) {
        //     return this.autoAjaxCall({ url: baseUrl + 'msg/sendMsgAli', data: data }, 'post');
        // },    
        // //保存每一步的数据到后台session
        // per_next_info(data,type) {
        //     return this.autoAjaxCall({ url: baseNode + 'per_next_info?type='+type, data: data }, 'post');
        // },
        
        //验证上传的法人身份证是否和印业执照上的一致
        legalVerify(data) {
            return this.autoAjaxCall({ url: baseNode + 'legal_verify', data: data }, 'post');
        }                
    }
}

