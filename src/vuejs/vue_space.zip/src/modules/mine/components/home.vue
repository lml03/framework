<template>
    <div>
        <p>这里是home页面</p>
    </div>

</template>
<script>



export default {
    mixins: [],
    components: { },
    data () {
        return {
            collapsed: false,
            currentIndex:1
        }
    },
    mounted () {
    },
    updated () {
    },
    activated () {

    },
    methods:{
        
    }
}
</script>
<style lang="scss">
    p{ color: #999;}



</style>
