<template>
    <div class="app">
        <router-view></router-view>
    </div>
</template>
<script>
require('../../assets/css/base.scss')
require('../../assets/css/common.scss')
export default {
    mixins: [],
    name: 'app',
    components: {  },
    mounted(){

    }
}

</script>

<style lang="scss" scoped>


</style>
