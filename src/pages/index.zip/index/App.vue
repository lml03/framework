<template>
    <div class="app">
        <router-view></router-view>
    </div>
</template>
<script>

export default {
    mixins: [],
    name: 'app',
    components: {  },
    mounted(){

    }
}

</script>
<style lang="scss" scoped>


</style>
